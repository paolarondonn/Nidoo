import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import Navbar from '@/components/layout/Navbar';
import DeleteAccountButton from '@/components/auth/DeleteAccountButton';
import { useAuth } from '@/lib/AuthContext';
import { Camera, Save, LogOut, Loader2, User } from 'lucide-react';

import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { motion } from 'framer-motion';

export default function Perfil() {
  const { user, logout, isLoadingAuth, authChecked } = useAuth();
  const queryClient = useQueryClient();
  const [subiendo, setSubiendo] = useState(false);
  const [guardado, setGuardado] = useState(false);

  const { data: perfil, isLoading } = useQuery({
    queryKey: ['perfil', user?.email],
    queryFn: async () => {
      const res = await base44.entities.UserProfile.filter({ usuario_email: user.email });
      return res[0] || null;
    },
    enabled: !!user,
  });

  const [form, setForm] = useState({
    nombre: '', telefono: '', bio: '', foto_url: '',
    tipo_busqueda: 'alquiler', presupuesto_max: '', ciudades_interes: [],
  });

  useEffect(() => {
    if (perfil) {
      setForm({
        nombre: perfil.nombre || user?.full_name || '',
        telefono: perfil.telefono || '',
        bio: perfil.bio || '',
        foto_url: perfil.foto_url || '',
        tipo_busqueda: perfil.tipo_busqueda || 'alquiler',
        presupuesto_max: perfil.presupuesto_max || '',
        ciudades_interes: perfil.ciudades_interes || [],
      });
    } else if (user) {
      setForm(f => ({ ...f, nombre: user.full_name || '' }));
    }
  }, [perfil, user]);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const saveMutation = useMutation({
    mutationFn: async () => {
      const data = {
        ...form,
        usuario_email: user.email,
        presupuesto_max: Number(form.presupuesto_max) || null,
      };
      if (perfil?.id) {
        await base44.entities.UserProfile.update(perfil.id, data);
      } else {
        await base44.entities.UserProfile.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['perfil'] });
      setGuardado(true);
      setTimeout(() => setGuardado(false), 2500);
    },
  });

  const subirFoto = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setSubiendo(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    set('foto_url', file_url);
    setSubiendo(false);
  };

  const toggleCiudad = (ciudad) => {
    const list = form.ciudades_interes;
    if (list.includes(ciudad)) {
      set('ciudades_interes', list.filter(c => c !== ciudad));
    } else {
      set('ciudades_interes', [...list, ciudad]);
    }
  };

  if (isLoadingAuth || !authChecked || isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex justify-center pt-32"><Loader2 size={28} className="animate-spin text-muted-foreground" /></div>
      </div>
    );
  }

  // Usuario sin perfil → pantalla de bienvenida
  if (!perfil) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="pt-20 md:pt-24 pb-28 md:pb-16 px-4 max-w-xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center py-12">
            <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
              <User size={36} className="text-primary" />
            </div>
            <h1 className="font-serif text-3xl md:text-4xl mb-2">Bienvenido a nido.</h1>
            <p className="text-muted-foreground mb-8">Completa tu perfil para empezar a buscar tu próximo hogar.</p>

            <div className="text-left space-y-6">
              <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
                <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Datos personales</h2>
                <div>
                  <Label>Nombre</Label>
                  <Input value={form.nombre} onChange={e => set('nombre', e.target.value)} placeholder="Tu nombre" className="mt-1" />
                </div>
                <div>
                  <Label>Teléfono</Label>
                  <Input value={form.telefono} onChange={e => set('telefono', e.target.value)} placeholder="+34 600 000 000" className="mt-1" />
                </div>
                <div>
                  <Label>Bio</Label>
                  <Textarea value={form.bio} onChange={e => set('bio', e.target.value)} placeholder="Cuéntanos algo sobre ti..." className="mt-1 min-h-20" />
                </div>
              </div>

              <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
                <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">¿Qué buscas?</h2>
                <div className="flex gap-2">
                  {['alquiler', 'compra', 'ambos'].map(t => (
                    <button type="button" key={t} onClick={() => set('tipo_busqueda', t)}
                      className={`flex-1 py-2 rounded-xl text-sm font-medium capitalize border transition-all ${form.tipo_busqueda === t ? 'bg-primary text-primary-foreground border-primary' : 'border-border text-muted-foreground hover:border-primary/40'}`}>
                      {t}
                    </button>
                  ))}
                </div>
                <div>
                  <Label>Presupuesto máximo (€)</Label>
                  <Input type="number" value={form.presupuesto_max} onChange={e => set('presupuesto_max', e.target.value)} placeholder="1.500" className="mt-1" />
                </div>
                <div>
                  <Label>Ciudades de interés</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {['Madrid', 'Barcelona', 'Valencia', 'Sevilla', 'Bilbao', 'Málaga', 'Zaragoza'].map(c => (
                      <button type="button" key={c} onClick={() => toggleCiudad(c)}
                        className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${form.ciudades_interes.includes(c) ? 'bg-primary text-primary-foreground border-primary' : 'border-border text-muted-foreground hover:border-primary/40'}`}>
                        {c}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <button
                onClick={() => saveMutation.mutate()}
                disabled={saveMutation.isPending}
                className="w-full bg-primary text-primary-foreground py-3.5 rounded-2xl font-semibold hover:bg-primary/90 transition-colors disabled:opacity-60 flex items-center justify-center gap-2"
              >
                {saveMutation.isPending ? <Loader2 size={16} className="animate-spin" /> : null}
                Crear mi perfil
              </button>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-20 md:pt-24 pb-28 md:pb-16 px-4 max-w-xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>

          <div>
          <h1 className="font-serif text-3xl md:text-4xl text-foreground mb-1">Mi perfil</h1>
          <p className="text-muted-foreground text-sm mb-8">{user.email}</p>

          {isLoading ? (
            <div className="flex justify-center py-16"><Loader2 size={28} className="animate-spin text-muted-foreground" /></div>
          ) : (
            <div className="space-y-6">
              {/* Foto */}
              <div className="flex items-center gap-5">
                <div className="relative">
                  <div className="w-20 h-20 rounded-full bg-accent border border-border overflow-hidden flex items-center justify-center">
                    {form.foto_url ? (
                      <img src={form.foto_url} alt="foto" className="w-full h-full object-cover" />
                    ) : (
                      <User size={32} className="text-muted-foreground" />
                    )}
                  </div>
                  <label className="absolute -bottom-1 -right-1 bg-primary text-primary-foreground rounded-full p-1.5 cursor-pointer hover:bg-primary/90 transition-colors">
                    {subiendo ? <Loader2 size={13} className="animate-spin" /> : <Camera size={13} />}
                    <input type="file" accept="image/*" className="hidden" onChange={subirFoto} disabled={subiendo} />
                  </label>
                </div>
                <div>
                  <p className="font-semibold">{form.nombre || user.full_name}</p>
                  <p className="text-xs text-muted-foreground">Miembro de nido.</p>
                </div>
              </div>

              {/* Datos personales */}
              <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
                <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Datos personales</h2>
                <div>
                  <Label>Nombre</Label>
                  <Input value={form.nombre} onChange={e => set('nombre', e.target.value)} placeholder="Tu nombre" className="mt-1" />
                </div>
                <div>
                  <Label>Teléfono</Label>
                  <Input value={form.telefono} onChange={e => set('telefono', e.target.value)} placeholder="+34 600 000 000" className="mt-1" />
                </div>
                <div>
                  <Label>Bio</Label>
                  <Textarea value={form.bio} onChange={e => set('bio', e.target.value)} placeholder="Cuéntanos algo sobre ti..." className="mt-1 min-h-20" />
                </div>
              </div>

              {/* Preferencias de búsqueda */}
              <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
                <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Preferencias de búsqueda</h2>
                <div>
                  <Label>Tipo de operación</Label>
                  <div className="flex gap-2 mt-2">
                    {['alquiler', 'compra', 'ambos'].map(t => (
                      <button type="button" key={t} onClick={() => set('tipo_busqueda', t)}
                        className={`flex-1 py-2 rounded-xl text-sm font-medium capitalize border transition-all ${form.tipo_busqueda === t ? 'bg-primary text-primary-foreground border-primary' : 'border-border text-muted-foreground hover:border-primary/40'}`}>
                        {t}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <Label>Presupuesto máximo (€)</Label>
                  <Input type="number" value={form.presupuesto_max} onChange={e => set('presupuesto_max', e.target.value)} placeholder="1.500" className="mt-1" />
                </div>
                <div>
                  <Label>Ciudades de interés</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {['Madrid', 'Barcelona', 'Valencia', 'Sevilla', 'Bilbao', 'Málaga', 'Zaragoza'].map(c => (
                      <button type="button" key={c} onClick={() => toggleCiudad(c)}
                        className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${form.ciudades_interes.includes(c) ? 'bg-primary text-primary-foreground border-primary' : 'border-border text-muted-foreground hover:border-primary/40'}`}>
                        {c}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Guardar */}
              <button
                onClick={() => saveMutation.mutate()}
                disabled={saveMutation.isPending}
                className="w-full bg-primary text-primary-foreground py-3.5 rounded-2xl font-semibold hover:bg-primary/90 transition-colors disabled:opacity-60 flex items-center justify-center gap-2"
              >
                {saveMutation.isPending ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
                {guardado ? '¡Guardado!' : 'Guardar perfil'}
              </button>

              {/* Sesión y cuenta */}
              <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
                <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Cuenta</h2>
                <button onClick={() => logout()} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors py-1">
                  <LogOut size={15} /> Cerrar sesión
                </button>
                <DeleteAccountButton />
              </div>
            </div>
          )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
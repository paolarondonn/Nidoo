import { useState, useMemo, useCallback } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import Navbar from '@/components/layout/Navbar';
import InmuebleCard from '@/components/inmuebles/InmuebleCard';
import FiltrosPanel from '@/components/busqueda/FiltrosPanel';
import BusquedaIA from '@/components/busqueda/BusquedaIA';
import { usePullToRefresh } from '@/hooks/usePullToRefresh';
import { MapPin, LayoutGrid, List, RefreshCw } from 'lucide-react';
import PlanesAgencias from '@/components/agencias/PlanesAgencias';
import { motion } from 'framer-motion';

const FILTROS_INICIALES = {
  tipo_operacion: 'alquiler',
  habitaciones: null,
  precioMin: null,
  precioMax: null,
  superficieMin: null,
  tipo_inmueble: null,
  certificado_energetico: null,
  orientacion: null,
  tipo_contrato: null,
  ciudad: '',
  extras: {},
  servicios: {},
};

export default function Home() {
  const [filtros, setFiltros] = useState(FILTROS_INICIALES);
  const [vista, setVista] = useState('grid');
  const queryClient = useQueryClient();

  const { data: inmuebles = [], isLoading, refetch } = useQuery({
    queryKey: ['inmuebles'],
    queryFn: () => base44.entities.Inmueble.filter({ activo: true }, '-created_date', 100),
  });

  const handleRefresh = useCallback(async () => {
    await refetch();
  }, [refetch]);

  const { pullDistance, refreshing } = usePullToRefresh(handleRefresh);

  const { data: user } = useQuery({
    queryKey: ['me'],
    queryFn: () => base44.auth.me().catch(() => null),
  });

  const { data: favoritos = [] } = useQuery({
    queryKey: ['favoritos', user?.email],
    queryFn: () => base44.entities.Favorito.filter({ usuario_email: user.email }),
    enabled: !!user,
  });

  const favoritosIds = new Set(favoritos.map((f) => f.inmueble_id));

  const handleToggleFavorito = async (inmuebleId) => {
    if (!user) return;
    const existing = favoritos.find((f) => f.inmueble_id === inmuebleId);
    const key = ['favoritos', user.email];
    if (existing) {
      // Optimistic remove
      queryClient.setQueryData(key, (old = []) => old.filter((f) => f.id !== existing.id));
      await base44.entities.Favorito.delete(existing.id);
    } else {
      // Optimistic add
      const temp = { id: `temp-${inmuebleId}`, inmueble_id: inmuebleId, usuario_email: user.email };
      queryClient.setQueryData(key, (old = []) => [...old, temp]);
      await base44.entities.Favorito.create({ inmueble_id: inmuebleId, usuario_email: user.email });
    }
    queryClient.invalidateQueries({ queryKey: key });
  };

  const resultados = useMemo(() => {
    return inmuebles.filter((i) => {
      if (filtros.tipo_operacion && i.tipo_operacion !== filtros.tipo_operacion) return false;
      if (filtros.habitaciones && i.habitaciones !== filtros.habitaciones) return false;
      if (filtros.precioMin && i.precio < filtros.precioMin) return false;
      if (filtros.precioMax && i.precio > filtros.precioMax) return false;
      if (filtros.superficieMin && i.superficie < filtros.superficieMin) return false;
      if (filtros.tipo_inmueble && i.tipo_inmueble !== filtros.tipo_inmueble) return false;
      if (filtros.certificado_energetico && i.certificado_energetico !== filtros.certificado_energetico) return false;
      if (filtros.orientacion && i.orientacion !== filtros.orientacion) return false;
      if (filtros.tipo_contrato && i.tipo_contrato !== filtros.tipo_contrato) return false;
      if (filtros.ciudad && !i.ciudad?.toLowerCase().includes(filtros.ciudad.toLowerCase())) return false;
      const extras = filtros.extras || {};
      for (const key of Object.keys(extras)) {
        if (extras[key] && !i.extras?.[key]) return false;
      }
      const servicios = filtros.servicios || {};
      for (const key of Object.keys(servicios)) {
        if (servicios[key] && !i.servicios_cercanos?.[key]) return false;
      }
      return true;
    });
  }, [inmuebles, filtros]);

  return (
    <div className="min-h-screen bg-background">
      {/* Pull-to-refresh indicator */}
      {(pullDistance > 0 || refreshing) && (
        <div
          className="fixed top-14 md:top-16 left-0 right-0 z-40 flex justify-center pointer-events-none"
          style={{ transform: `translateY(${refreshing ? 8 : pullDistance - 40}px)`, transition: refreshing ? 'transform 0.2s' : 'none' }}
        >
          <div className="bg-card border border-border rounded-full p-2 shadow-md">
            <RefreshCw size={16} className={`text-primary ${refreshing ? 'animate-spin' : ''}`} />
          </div>
        </div>
      )}
      <Navbar />

      {/* Hero */}
      <section className="pt-20 md:pt-24 pb-8 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
            <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-2 leading-tight">
              Encuentra tu próximo <em>nido.</em>
            </h1>
            <p className="text-muted-foreground text-lg">Sin anuncios. Sin opacidad. Solo el piso que necesitas.</p>
          </motion.div>

          {/* Toggle alquiler/compra + Ciudad */}
          <div className="flex flex-wrap items-center gap-3 mb-4">
            <div className="flex bg-secondary rounded-xl p-1">
              {['alquiler', 'compra'].map((op) => (
                <button key={op} onClick={() => setFiltros({ ...filtros, tipo_operacion: op, precioMin: null, precioMax: null })}
                  className={`px-5 py-2 rounded-lg text-sm font-semibold capitalize transition-all ${filtros.tipo_operacion === op ? 'bg-primary text-primary-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}>
                  {op}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2 bg-card border border-border rounded-xl px-4 py-2.5 flex-1 max-w-xs">
              <MapPin size={16} className="text-muted-foreground shrink-0" />
              <input
                value={filtros.ciudad}
                onChange={(e) => setFiltros({ ...filtros, ciudad: e.target.value })}
                placeholder="Ciudad, barrio..."
                className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
              />
            </div>
          </div>

          {/* Búsqueda IA */}
          <div className="mb-4">
            <BusquedaIA onFiltrosGenerados={(f) => setFiltros({ ...filtros, ...f })} />
          </div>

          {/* Filtros */}
          <FiltrosPanel
            filtros={filtros}
            onChange={setFiltros}
            onClear={() => setFiltros(FILTROS_INICIALES)}
          />
        </div>
      </section>

      {/* Resultados */}
      <section className="px-4 pb-24 md:pb-16">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-5">
            <p className="text-muted-foreground text-sm">
              {isLoading ? 'Cargando...' : <><span className="font-semibold text-foreground">{resultados.length}</span> inmuebles encontrados</>}
            </p>
            <div className="flex items-center gap-1">
              <button onClick={() => setVista('grid')} className={`p-2.5 rounded-lg transition-colors min-w-[44px] min-h-[44px] flex items-center justify-center ${vista === 'grid' ? 'bg-primary text-primary-foreground' : 'hover:bg-accent text-muted-foreground'}`}>
                <LayoutGrid size={16} />
              </button>
              <button onClick={() => setVista('list')} className={`p-2.5 rounded-lg transition-colors min-w-[44px] min-h-[44px] flex items-center justify-center ${vista === 'list' ? 'bg-primary text-primary-foreground' : 'hover:bg-accent text-muted-foreground'}`}>
                <List size={16} />
              </button>
            </div>
          </div>

          {isLoading ? (
            <div className={`grid gap-5 ${vista === 'grid' ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3' : 'grid-cols-1'}`}>
              {Array(6).fill(0).map((_, i) => (
                <div key={i} className="bg-card rounded-2xl border border-border overflow-hidden animate-pulse">
                  <div className="aspect-[4/3] bg-muted" />
                  <div className="p-4 space-y-2">
                    <div className="h-3 bg-muted rounded w-1/3" />
                    <div className="h-5 bg-muted rounded w-3/4" />
                    <div className="h-3 bg-muted rounded w-1/2" />
                    <div className="h-6 bg-muted rounded w-1/4" />
                  </div>
                </div>
              ))}
            </div>
          ) : resultados.length === 0 ? (
            <div className="text-center py-20">
              <p className="font-serif text-2xl text-muted-foreground mb-2">Sin resultados</p>
              <p className="text-muted-foreground text-sm">Prueba a cambiar los filtros de búsqueda</p>
            </div>
          ) : (
            <div className={`grid gap-5 ${vista === 'grid' ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3' : 'grid-cols-1 max-w-2xl'}`}>
              {resultados.map((inmueble) => (
                <InmuebleCard
                  key={inmueble.id}
                  inmueble={inmueble}
                  isFavorito={favoritosIds.has(inmueble.id)}
                  onToggleFavorito={handleToggleFavorito}
                />
              ))}
            </div>
          )}
        </div>
      </section>
      <PlanesAgencias />
    </div>
  );
}
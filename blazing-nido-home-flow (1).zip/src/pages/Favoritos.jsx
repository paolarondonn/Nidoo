import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import Navbar from '@/components/layout/Navbar';
import InmuebleCard from '@/components/inmuebles/InmuebleCard';
import { Heart } from 'lucide-react';
import { motion } from 'framer-motion';

export default function Favoritos() {
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['me'],
    queryFn: () => base44.auth.me().catch(() => null),
  });

  const { data: favoritosRaw = [], isLoading } = useQuery({
    queryKey: ['favoritos', user?.email],
    queryFn: () => base44.entities.Favorito.filter({ usuario_email: user.email }),
    enabled: !!user,
  });

  const inmuebleIds = favoritosRaw.map((f) => f.inmueble_id);

  const { data: inmuebles = [] } = useQuery({
    queryKey: ['inmuebles-favoritos', inmuebleIds.join(',')],
    queryFn: async () => {
      if (!inmuebleIds.length) return [];
      const all = await base44.entities.Inmueble.list();
      return all.filter((i) => inmuebleIds.includes(i.id));
    },
    enabled: inmuebleIds.length > 0,
  });

  const deleteMutation = useMutation({
    mutationFn: async (inmuebleId) => {
      const fav = favoritosRaw.find((f) => f.inmueble_id === inmuebleId);
      if (fav) await base44.entities.Favorito.delete(fav.id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['favoritos'] });
      queryClient.invalidateQueries({ queryKey: ['inmuebles-favoritos'] });
    },
  });

  const favoritosIds = new Set(inmuebleIds);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-20 md:pt-24 pb-28 md:pb-16 px-4 max-w-6xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <h1 className="font-serif text-3xl md:text-4xl text-foreground mb-1">Mis favoritos</h1>
          <p className="text-muted-foreground">{inmuebles.length} inmuebles guardados</p>
        </motion.div>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {Array(3).fill(0).map((_, i) => (
              <div key={i} className="bg-card rounded-2xl border border-border overflow-hidden animate-pulse">
                <div className="aspect-[4/3] bg-muted" />
                <div className="p-4 space-y-2">
                  <div className="h-3 bg-muted rounded w-1/3" />
                  <div className="h-5 bg-muted rounded w-3/4" />
                  <div className="h-6 bg-muted rounded w-1/4" />
                </div>
              </div>
            ))}
          </div>
        ) : inmuebles.length === 0 ? (
          <div className="text-center py-24">
            <div className="w-16 h-16 rounded-full bg-accent flex items-center justify-center mx-auto mb-4">
              <Heart size={28} className="text-muted-foreground" />
            </div>
            <p className="font-serif text-2xl text-muted-foreground mb-2">Sin favoritos aún</p>
            <p className="text-muted-foreground text-sm">Guarda los pisos que te gusten para encontrarlos aquí</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {inmuebles.map((inmueble) => (
              <InmuebleCard
                key={inmueble.id}
                inmueble={inmueble}
                isFavorito={favoritosIds.has(inmueble.id)}
                onToggleFavorito={(id) => deleteMutation.mutate(id)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
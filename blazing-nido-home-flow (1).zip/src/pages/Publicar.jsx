import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import Navbar from '@/components/layout/Navbar';
import DrawerSelect from '@/components/ui/DrawerSelect';
import { Upload, X, CheckCircle2, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';

const EXTRAS_LIST = ['garaje', 'terraza', 'piscina', 'mascotas', 'accesibilidad', 'aire_acondicionado', 'calefaccion', 'ascensor', 'trastero'];
const SERVICIOS_LIST = ['metro', 'colegio', 'supermercado', 'hospital', 'parque', 'carril_bici'];

export default function Publicar() {
  const navigate = useNavigate();
  const [enviado, setEnviado] = useState(false);
  const [cargando, setCargando] = useState(false);
  const [subiendo, setSubiendo] = useState(false);
  const [form, setForm] = useState({
    titulo: '', descripcion: '', tipo_operacion: 'alquiler', tipo_inmueble: 'piso',
    precio: '', superficie: '', habitaciones: '', banos: '', planta: '',
    ciudad: '', barrio: '', direccion: '', orientacion: '', certificado_energetico: '',
    estado: 'buen estado', tipo_contrato: 'larga duración',
    anunciante_nombre: '', anunciante_email: '', anunciante_telefono: '', anunciante_tipo: 'particular',
    fotos: [], extras: {}, servicios_cercanos: {},
  });

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const toggleExtra = (k) => set('extras', { ...form.extras, [k]: !form.extras[k] });
  const toggleServicio = (k) => set('servicios_cercanos', { ...form.servicios_cercanos, [k]: !form.servicios_cercanos[k] });

  const subirFoto = async (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    setSubiendo(true);
    const urls = [];
    for (const file of files) {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      urls.push(file_url);
    }
    set('fotos', [...form.fotos, ...urls]);
    setSubiendo(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setCargando(true);
    await base44.entities.Inmueble.create({
      ...form,
      precio: Number(form.precio),
      superficie: Number(form.superficie) || null,
      habitaciones: Number(form.habitaciones) || null,
      banos: Number(form.banos) || null,
      dias_publicado: 0,
      activo: true,
    });
    setCargando(false);
    setEnviado(true);
  };

  if (enviado) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="pt-20 md:pt-24 flex items-center justify-center px-4">
          <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-center max-w-md">
            <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-5">
              <CheckCircle2 size={36} className="text-primary" />
            </div>
            <h2 className="font-serif text-3xl mb-2">¡Anuncio publicado!</h2>
            <p className="text-muted-foreground mb-6">Tu inmueble ya está visible para los usuarios de nido.</p>
            <div className="flex gap-3 justify-center">
              <button onClick={() => navigate('/')} className="bg-primary text-primary-foreground px-6 py-2.5 rounded-xl text-sm font-medium hover:bg-primary/90 transition-colors">
                Ver todos los pisos
              </button>
              <button onClick={() => { setEnviado(false); setForm({ titulo: '', descripcion: '', tipo_operacion: 'alquiler', tipo_inmueble: 'piso', precio: '', superficie: '', habitaciones: '', banos: '', planta: '', ciudad: '', barrio: '', direccion: '', orientacion: '', certificado_energetico: '', estado: 'buen estado', tipo_contrato: 'larga duración', anunciante_nombre: '', anunciante_email: '', anunciante_telefono: '', anunciante_tipo: 'particular', fotos: [], extras: {}, servicios_cercanos: {} }); }}
                className="border border-border px-6 py-2.5 rounded-xl text-sm font-medium hover:bg-accent transition-colors">
                Publicar otro
              </button>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-20 md:pt-24 pb-28 md:pb-16 px-4 max-w-2xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <h1 className="font-serif text-3xl md:text-4xl text-foreground mb-1">Publicar inmueble</h1>
          <p className="text-muted-foreground">Publica tu piso de forma gratuita en nido.</p>
        </motion.div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Tipo de operación */}
          <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
            <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Tipo de operación</h2>
            <div className="flex gap-2">
              {['alquiler', 'compra'].map((op) => (
                <button type="button" key={op} onClick={() => set('tipo_operacion', op)}
                  className={`flex-1 py-2.5 rounded-xl text-sm font-semibold capitalize transition-all border ${form.tipo_operacion === op ? 'bg-primary text-primary-foreground border-primary' : 'border-border text-muted-foreground hover:border-primary/40'}`}>
                  {op}
                </button>
              ))}
            </div>
            <div className="flex flex-wrap gap-2">
              {['piso', 'casa', 'estudio', 'ático', 'dúplex', 'local'].map((t) => (
                <button type="button" key={t} onClick={() => set('tipo_inmueble', t)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all capitalize ${form.tipo_inmueble === t ? 'bg-primary text-primary-foreground border-primary' : 'border-border text-muted-foreground hover:border-primary/40'}`}>
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Info básica */}
          <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
            <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Información básica</h2>
            <div>
              <Label htmlFor="titulo">Título del anuncio *</Label>
              <Input id="titulo" value={form.titulo} onChange={(e) => set('titulo', e.target.value)} required placeholder="Ej: Piso luminoso con terraza en Malasaña" className="mt-1" />
            </div>
            <div>
              <Label htmlFor="desc">Descripción</Label>
              <Textarea id="desc" value={form.descripcion} onChange={(e) => set('descripcion', e.target.value)} placeholder="Describe el piso, el entorno, lo que lo hace especial..." className="mt-1 min-h-24" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="precio">Precio (€) *</Label>
                <Input id="precio" type="number" value={form.precio} onChange={(e) => set('precio', e.target.value)} required placeholder={form.tipo_operacion === 'alquiler' ? '1.200' : '250.000'} className="mt-1" />
              </div>
              <div>
                <Label htmlFor="superficie">Superficie (m²)</Label>
                <Input id="superficie" type="number" value={form.superficie} onChange={(e) => set('superficie', e.target.value)} placeholder="75" className="mt-1" />
              </div>
              <div>
                <Label htmlFor="habitaciones">Habitaciones</Label>
                <Input id="habitaciones" type="number" value={form.habitaciones} onChange={(e) => set('habitaciones', e.target.value)} placeholder="2" className="mt-1" />
              </div>
              <div>
                <Label htmlFor="banos">Baños</Label>
                <Input id="banos" type="number" value={form.banos} onChange={(e) => set('banos', e.target.value)} placeholder="1" className="mt-1" />
              </div>
            </div>
          </div>

          {/* Ubicación */}
          <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
            <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Ubicación</h2>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Ciudad *</Label>
                <Input value={form.ciudad} onChange={(e) => set('ciudad', e.target.value)} required placeholder="Madrid" className="mt-1" />
              </div>
              <div>
                <Label>Barrio</Label>
                <Input value={form.barrio} onChange={(e) => set('barrio', e.target.value)} placeholder="Malasaña" className="mt-1" />
              </div>
            </div>
            <div>
              <Label>Dirección</Label>
              <Input value={form.direccion} onChange={(e) => set('direccion', e.target.value)} placeholder="Calle, número..." className="mt-1" />
            </div>
          </div>

          {/* Detalles */}
          <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
            <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Detalles</h2>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Orientación</Label>
                <DrawerSelect
                  label="Orientación"
                  value={form.orientacion}
                  onChange={(v) => set('orientacion', v)}
                  options={['norte', 'sur', 'este', 'oeste', 'sureste', 'suroeste'].map((o) => ({ value: o, label: o }))}
                />
              </div>
              <div>
                <Label>Certificado energético</Label>
                <DrawerSelect
                  label="Certificado energético"
                  value={form.certificado_energetico}
                  onChange={(v) => set('certificado_energetico', v)}
                  options={['A', 'B', 'C', 'D', 'E', 'F', 'G'].map((c) => ({ value: c, label: c }))}
                />
              </div>
            </div>
            <div>
              <Label>Tipo de contrato</Label>
              <div className="flex flex-wrap gap-2 mt-2">
                {['larga duración', 'temporal', 'estudiantes'].map((c) => (
                  <button type="button" key={c} onClick={() => set('tipo_contrato', c)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all capitalize ${form.tipo_contrato === c ? 'bg-primary text-primary-foreground border-primary' : 'border-border text-muted-foreground hover:border-primary/40'}`}>
                    {c}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Extras */}
          <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
            <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Extras y servicios</h2>
            <div>
              <p className="text-xs text-muted-foreground mb-2">Características del inmueble</p>
              <div className="flex flex-wrap gap-2">
                {EXTRAS_LIST.map((k) => (
                  <button type="button" key={k} onClick={() => toggleExtra(k)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${form.extras[k] ? 'bg-primary text-primary-foreground border-primary' : 'border-border text-muted-foreground hover:border-primary/40'}`}>
                    {k.replace('_', ' ')}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-2">Servicios cercanos</p>
              <div className="flex flex-wrap gap-2">
                {SERVICIOS_LIST.map((k) => (
                  <button type="button" key={k} onClick={() => toggleServicio(k)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${form.servicios_cercanos[k] ? 'bg-primary text-primary-foreground border-primary' : 'border-border text-muted-foreground hover:border-primary/40'}`}>
                    {k.replace('_', ' ')}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Fotos */}
          <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
            <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Fotos</h2>
            <div className="grid grid-cols-3 gap-3">
              {form.fotos.map((url, i) => (
                <div key={i} className="relative aspect-square rounded-xl overflow-hidden">
                  <img src={url} alt="" className="w-full h-full object-cover" />
                  <button type="button" onClick={() => set('fotos', form.fotos.filter((_, j) => j !== i))}
                    className="absolute top-1 right-1 bg-black/60 text-white rounded-full p-0.5">
                    <X size={12} />
                  </button>
                </div>
              ))}
              <label className={`aspect-square rounded-xl border-2 border-dashed border-border flex flex-col items-center justify-center cursor-pointer hover:border-primary/50 hover:bg-accent/50 transition-all ${subiendo ? 'opacity-50' : ''}`}>
                {subiendo ? <Loader2 size={20} className="animate-spin text-muted-foreground" /> : <><Upload size={20} className="text-muted-foreground mb-1" /><span className="text-xs text-muted-foreground">Añadir foto</span></>}
                <input type="file" multiple accept="image/*" onChange={subirFoto} className="hidden" disabled={subiendo} />
              </label>
            </div>
          </div>

          {/* Datos anunciante */}
          <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
            <h2 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">Tus datos de contacto</h2>
            <div className="flex gap-2 mb-2">
              {['particular', 'agencia'].map((t) => (
                <button type="button" key={t} onClick={() => set('anunciante_tipo', t)}
                  className={`flex-1 py-2 rounded-xl text-sm font-medium capitalize border transition-all ${form.anunciante_tipo === t ? 'bg-primary text-primary-foreground border-primary' : 'border-border text-muted-foreground hover:border-primary/40'}`}>
                  {t}
                </button>
              ))}
            </div>
            <div className="grid grid-cols-1 gap-4">
              <div>
                <Label>Nombre *</Label>
                <Input value={form.anunciante_nombre} onChange={(e) => set('anunciante_nombre', e.target.value)} required placeholder="Tu nombre o el de tu agencia" className="mt-1" />
              </div>
              <div>
                <Label>Email *</Label>
                <Input type="email" value={form.anunciante_email} onChange={(e) => set('anunciante_email', e.target.value)} required placeholder="contacto@ejemplo.com" className="mt-1" />
              </div>
              <div>
                <Label>Teléfono</Label>
                <Input value={form.anunciante_telefono} onChange={(e) => set('anunciante_telefono', e.target.value)} placeholder="+34 600 000 000" className="mt-1" />
              </div>
            </div>
          </div>

          <button type="submit" disabled={cargando}
            className="w-full bg-primary text-primary-foreground py-4 rounded-2xl text-base font-semibold hover:bg-primary/90 transition-colors disabled:opacity-60 flex items-center justify-center gap-2">
            {cargando ? <><Loader2 size={18} className="animate-spin" /> Publicando...</> : 'Publicar inmueble gratis'}
          </button>
        </form>
      </div>
    </div>
  );
}
import { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import Navbar from '@/components/layout/Navbar';
import ContactoForm from '@/components/inmuebles/ContactoForm';
import ChatButton from '@/components/mensajes/ChatButton';
import {
  Heart, MapPin, BedDouble, Bath, Maximize2, ArrowLeft, Clock, TrendingDown,
  Zap, Wind, Volume2, ChevronLeft, ChevronRight, Phone, Mail, Calendar,
  Car, Trees, Waves, PawPrint, Accessibility, Thermometer, Building2, Bike,
  ShoppingCart, Stethoscope, School, Navigation
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const energyColors = {
  A: 'bg-green-100 text-green-800',
  B: 'bg-lime-100 text-lime-800',
  C: 'bg-yellow-100 text-yellow-800',
  D: 'bg-orange-100 text-orange-800',
  E: 'bg-orange-100 text-orange-800',
  F: 'bg-red-100 text-red-800',
  G: 'bg-red-200 text-red-900',
};

const extraIcons = {
  garaje: Car, terraza: Trees, piscina: Waves, mascotas: PawPrint,
  accesibilidad: Accessibility, aire_acondicionado: Wind, calefaccion: Thermometer,
  ascensor: Building2, trastero: Building2,
};

const servicioIcons = {
  metro: Navigation, colegio: School, supermercado: ShoppingCart,
  hospital: Stethoscope, parque: Trees, carril_bici: Bike,
};

export default function InmuebleDetalle() {
  const { id } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [fotoIdx, setFotoIdx] = useState(0);
  const [showContacto, setShowContacto] = useState(false);

  const handleBack = () => {
    if (window.history.length > 1) {
      navigate(-1);
    } else {
      navigate('/');
    }
  };

  const { data: inmueble, isLoading } = useQuery({
    queryKey: ['inmueble', id],
    queryFn: () => base44.entities.Inmueble.filter({ id }),
    select: (data) => data[0],
  });

  const { data: user } = useQuery({
    queryKey: ['me'],
    queryFn: () => base44.auth.me().catch(() => null),
  });

  const { data: favoritosUser = [] } = useQuery({
    queryKey: ['favoritos', user?.email],
    queryFn: () => base44.entities.Favorito.filter({ usuario_email: user.email }),
    enabled: !!user,
  });

  const isFavorito = favoritosUser.some((f) => f.inmueble_id === id);

  const toggleFav = async () => {
    if (!user) return;
    const existing = favoritosUser.find((f) => f.inmueble_id === id);
    const key = ['favoritos', user.email];
    if (existing) {
      queryClient.setQueryData(key, (old = []) => old.filter((f) => f.id !== existing.id));
      await base44.entities.Favorito.delete(existing.id);
    } else {
      const temp = { id: `temp-${id}`, inmueble_id: id, usuario_email: user.email };
      queryClient.setQueryData(key, (old = []) => [...old, temp]);
      await base44.entities.Favorito.create({ inmueble_id: id, usuario_email: user.email });
    }
    queryClient.invalidateQueries({ queryKey: key });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="pt-24 max-w-4xl mx-auto px-4">
          <div className="aspect-video bg-muted rounded-2xl animate-pulse mb-6" />
          <div className="space-y-3">
            <div className="h-8 bg-muted rounded w-2/3 animate-pulse" />
            <div className="h-4 bg-muted rounded w-1/3 animate-pulse" />
            <div className="h-10 bg-muted rounded w-1/4 animate-pulse" />
          </div>
        </div>
      </div>
    );
  }

  if (!inmueble) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="pt-24 text-center"><p className="text-muted-foreground">Inmueble no encontrado</p></div>
      </div>
    );
  }

  const fotos = inmueble.fotos?.length
    ? inmueble.fotos
    : ['https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=900&q=80'];

  const precioBajado = inmueble.precio_original && inmueble.precio < inmueble.precio_original;
  const activeExtras = Object.entries(inmueble.extras || {}).filter(([, v]) => v);
  const activeServicios = Object.entries(inmueble.servicios_cercanos || {}).filter(([, v]) => v);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-16 md:pt-20 max-w-5xl mx-auto px-4 pb-28 md:pb-16">
        {/* Back */}
        <button onClick={handleBack} className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mt-4 mb-4">
          <ArrowLeft size={15} /> Volver
        </button>

        {/* Galería */}
        <div className="relative rounded-2xl overflow-hidden aspect-video mb-6 bg-muted group">
          <AnimatePresence mode="wait">
            <motion.img
              key={fotoIdx}
              src={fotos[fotoIdx]}
              alt={inmueble.titulo}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="w-full h-full object-cover"
            />
          </AnimatePresence>
          {fotos.length > 1 && (
            <>
              <button onClick={() => setFotoIdx((fotoIdx - 1 + fotos.length) % fotos.length)}
                className="absolute left-3 top-1/2 -translate-y-1/2 bg-black/50 text-white rounded-full p-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <ChevronLeft size={18} />
              </button>
              <button onClick={() => setFotoIdx((fotoIdx + 1) % fotos.length)}
                className="absolute right-3 top-1/2 -translate-y-1/2 bg-black/50 text-white rounded-full p-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <ChevronRight size={18} />
              </button>
              <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
                {fotos.map((_, i) => (
                  <button key={i} onClick={() => setFotoIdx(i)}
                    className={`w-2 h-2 rounded-full transition-all ${i === fotoIdx ? 'bg-white' : 'bg-white/50'}`} />
                ))}
              </div>
            </>
          )}
          <button onClick={toggleFav}
            className={`absolute top-4 right-4 min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full backdrop-blur-sm transition-all ${isFavorito ? 'bg-red-500 text-white' : 'bg-white/80 text-gray-600 hover:bg-white'}`}>
            <Heart size={18} fill={isFavorito ? 'currentColor' : 'none'} />
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Contenido principal */}
          <div className="lg:col-span-2 space-y-6">
            {/* Cabecera */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs text-muted-foreground uppercase tracking-wider font-medium">
                  {inmueble.tipo_inmueble} en {inmueble.tipo_operacion}
                </span>
                {inmueble.certificado_energetico && (
                  <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${energyColors[inmueble.certificado_energetico] || ''}`}>
                    {inmueble.certificado_energetico}
                  </span>
                )}
                {precioBajado && (
                  <span className="text-xs bg-destructive/10 text-destructive px-2 py-0.5 rounded-full flex items-center gap-1">
                    <TrendingDown size={11} /> Precio bajado
                  </span>
                )}
              </div>
              <h1 className="font-serif text-3xl md:text-4xl leading-tight text-foreground mb-3">{inmueble.titulo}</h1>
              <div className="flex items-center gap-1.5 text-muted-foreground text-sm mb-4">
                <MapPin size={14} />
                <span>{[inmueble.barrio, inmueble.ciudad, inmueble.direccion].filter(Boolean).join(', ')}</span>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="font-serif text-4xl">{inmueble.precio?.toLocaleString('es-ES')}€</span>
                {inmueble.tipo_operacion === 'alquiler' && <span className="text-muted-foreground">/mes</span>}
                {precioBajado && <span className="text-sm text-muted-foreground line-through">{inmueble.precio_original?.toLocaleString('es-ES')}€</span>}
              </div>
            </div>

            {/* Stats */}
            <div className="flex flex-wrap gap-4 py-5 border-y border-border">
              {inmueble.habitaciones && <div className="flex items-center gap-2"><BedDouble size={18} className="text-muted-foreground" /><span className="font-medium">{inmueble.habitaciones} habitaciones</span></div>}
              {inmueble.banos && <div className="flex items-center gap-2"><Bath size={18} className="text-muted-foreground" /><span className="font-medium">{inmueble.banos} baños</span></div>}
              {inmueble.superficie && <div className="flex items-center gap-2"><Maximize2 size={18} className="text-muted-foreground" /><span className="font-medium">{inmueble.superficie} m²</span></div>}
              {inmueble.planta && <div className="flex items-center gap-2"><Building2 size={18} className="text-muted-foreground" /><span className="font-medium">Planta {inmueble.planta}</span></div>}
              {inmueble.orientacion && <div className="text-sm text-muted-foreground capitalize">Orientación {inmueble.orientacion}</div>}
              {inmueble.dias_publicado > 0 && <div className="flex items-center gap-1 text-sm text-muted-foreground ml-auto"><Clock size={14} />Publicado hace {inmueble.dias_publicado} días</div>}
            </div>

            {/* Descripción */}
            {inmueble.descripcion && (
              <div>
                <h2 className="font-serif text-xl mb-3">Descripción</h2>
                <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap">{inmueble.descripcion}</p>
              </div>
            )}

            {/* Transparencia */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {inmueble.ruido_zona && (
                <div className="bg-card border border-border rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-1"><Volume2 size={15} className="text-muted-foreground" /><span className="text-xs text-muted-foreground">Nivel de ruido</span></div>
                  <p className="font-semibold capitalize">{inmueble.ruido_zona}</p>
                </div>
              )}
              {inmueble.calidad_aire && (
                <div className="bg-card border border-border rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-1"><Wind size={15} className="text-muted-foreground" /><span className="text-xs text-muted-foreground">Calidad del aire</span></div>
                  <p className="font-semibold capitalize">{inmueble.calidad_aire}</p>
                </div>
              )}
              {inmueble.estado && (
                <div className="bg-card border border-border rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-1"><Zap size={15} className="text-muted-foreground" /><span className="text-xs text-muted-foreground">Estado</span></div>
                  <p className="font-semibold capitalize">{inmueble.estado}</p>
                </div>
              )}
            </div>

            {/* Extras */}
            {activeExtras.length > 0 && (
              <div>
                <h2 className="font-serif text-xl mb-3">Características</h2>
                <div className="flex flex-wrap gap-2">
                  {activeExtras.map(([key]) => {
                    const Icon = extraIcons[key] || Zap;
                    return (
                      <span key={key} className="flex items-center gap-1.5 bg-accent text-accent-foreground px-3 py-2 rounded-xl text-sm capitalize">
                        <Icon size={14} /> {key.replace('_', ' ')}
                      </span>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Servicios */}
            {activeServicios.length > 0 && (
              <div>
                <h2 className="font-serif text-xl mb-3">Servicios cercanos</h2>
                <div className="flex flex-wrap gap-2">
                  {activeServicios.map(([key]) => {
                    const Icon = servicioIcons[key] || MapPin;
                    return (
                      <span key={key} className="flex items-center gap-1.5 bg-primary/10 text-primary px-3 py-2 rounded-xl text-sm capitalize">
                        <Icon size={14} /> {key.replace('_', ' ')}
                      </span>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar contacto */}
          <div className="lg:col-span-1">
            <div className="sticky top-20 bg-card border border-border rounded-2xl p-5 space-y-4">
              {inmueble.anunciante_nombre && (
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wider mb-2">Anunciante</p>
                  <p className="font-semibold">{inmueble.anunciante_nombre}</p>
                  <p className="text-xs text-muted-foreground capitalize">{inmueble.anunciante_tipo}</p>
                </div>
              )}

              <button
                onClick={() => setShowContacto(!showContacto)}
                className="w-full bg-primary text-primary-foreground py-3 rounded-xl font-semibold hover:bg-primary/90 transition-colors flex items-center justify-center gap-2"
              >
                <Calendar size={16} /> Solicitar visita
              </button>

              {inmueble.anunciante_telefono && (
                <a href={`tel:${inmueble.anunciante_telefono}`}
                  className="w-full flex items-center justify-center gap-2 border border-border py-3 rounded-xl text-sm font-medium hover:bg-accent transition-colors">
                  <Phone size={15} /> {inmueble.anunciante_telefono}
                </a>
              )}
              {inmueble.anunciante_email && (
                <a href={`mailto:${inmueble.anunciante_email}`}
                  className="w-full flex items-center justify-center gap-2 border border-border py-3 rounded-xl text-sm font-medium hover:bg-accent transition-colors">
                  <Mail size={15} /> Enviar email
                </a>
              )}

              {inmueble.anunciante_email && (
                <ChatButton
                  inmuebleId={id}
                  inmuebleTitulo={inmueble.titulo}
                  anuncianteEmail={inmueble.anunciante_email}
                  user={user}
                />
              )}

              <AnimatePresence>
                {showContacto && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}>
                    <ContactoForm inmuebleId={id} inmuebleTitulo={inmueble.titulo} onSuccess={() => setShowContacto(false)} />
                  </motion.div>
                )}
              </AnimatePresence>

              <p className="text-xs text-muted-foreground text-center">Publicado en nido. · Sin intermediarios</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
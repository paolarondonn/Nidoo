import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import Navbar from '@/components/layout/Navbar';
import ChatConversacion from '@/components/mensajes/ChatConversacion';
import { MessageCircle, ArrowLeft } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function Mensajes() {
  const [conversacionActiva, setConversacionActiva] = useState(null); // { inmueble_id, inmueble_titulo, otro_email }
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['me'],
    queryFn: () => base44.auth.me().catch(() => null),
  });

  const { data: mensajes = [], isLoading } = useQuery({
    queryKey: ['mensajes', user?.email],
    queryFn: async () => {
      const enviados = await base44.entities.Mensaje.filter({ remitente_email: user.email });
      const recibidos = await base44.entities.Mensaje.filter({ destinatario_email: user.email });
      return [...enviados, ...recibidos];
    },
    enabled: !!user,
    refetchInterval: 8000,
  });

  // Agrupar por conversación (inmueble_id + otro_email)
  const conversaciones = [];
  const seen = new Set();
  for (const m of mensajes) {
    const otroEmail = m.remitente_email === user?.email ? m.destinatario_email : m.remitente_email;
    const key = `${m.inmueble_id}__${otroEmail}`;
    if (!seen.has(key)) {
      seen.add(key);
      const msgs = mensajes.filter(x =>
        x.inmueble_id === m.inmueble_id &&
        (x.remitente_email === otroEmail || x.destinatario_email === otroEmail)
      );
      const ultimo = msgs.sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0];
      const noLeidos = msgs.filter(x => x.destinatario_email === user.email && !x.leido).length;
      conversaciones.push({
        inmueble_id: m.inmueble_id,
        inmueble_titulo: m.inmueble_titulo,
        otro_email: otroEmail,
        ultimo_mensaje: ultimo?.contenido,
        ultima_fecha: ultimo?.created_date,
        no_leidos: noLeidos,
      });
    }
  }
  conversaciones.sort((a, b) => new Date(b.ultima_fecha) - new Date(a.ultima_fecha));

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-20 md:pt-24 pb-28 md:pb-16 px-4 max-w-2xl mx-auto">
        <AnimatePresence mode="wait">
          {conversacionActiva ? (
            <motion.div key="chat" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 30 }}>
              <button onClick={() => setConversacionActiva(null)} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-4 transition-colors">
                <ArrowLeft size={15} /> Todas las conversaciones
              </button>
              <ChatConversacion
                inmuebleId={conversacionActiva.inmueble_id}
                inmuebleTitulo={conversacionActiva.inmueble_titulo}
                otroEmail={conversacionActiva.otro_email}
                user={user}
              />
            </motion.div>
          ) : (
            <motion.div key="lista" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }}>
              <h1 className="font-serif text-3xl md:text-4xl text-foreground mb-1">Mensajes</h1>
              <p className="text-muted-foreground text-sm mb-8">Tus conversaciones con anunciantes</p>

              {isLoading ? (
                <div className="space-y-3">
                  {[1,2,3].map(i => (
                    <div key={i} className="bg-card border border-border rounded-2xl p-4 animate-pulse">
                      <div className="h-4 bg-muted rounded w-1/2 mb-2" />
                      <div className="h-3 bg-muted rounded w-3/4" />
                    </div>
                  ))}
                </div>
              ) : conversaciones.length === 0 ? (
                <div className="text-center py-24">
                  <div className="w-16 h-16 rounded-full bg-accent flex items-center justify-center mx-auto mb-4">
                    <MessageCircle size={28} className="text-muted-foreground" />
                  </div>
                  <p className="font-serif text-2xl text-muted-foreground mb-2">Sin mensajes aún</p>
                  <p className="text-muted-foreground text-sm">Contacta con un anunciante desde la ficha de un piso</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {conversaciones.map(conv => (
                    <button
                      key={`${conv.inmueble_id}_${conv.otro_email}`}
                      onClick={() => setConversacionActiva(conv)}
                      className="w-full bg-card border border-border rounded-2xl p-4 text-left hover:shadow-md hover:-translate-y-0.5 transition-all"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-sm truncate">{conv.inmueble_titulo || 'Piso'}</p>
                          <p className="text-xs text-muted-foreground truncate mt-0.5">{conv.otro_email}</p>
                          <p className="text-sm text-muted-foreground truncate mt-1">{conv.ultimo_mensaje}</p>
                        </div>
                        {conv.no_leidos > 0 && (
                          <span className="bg-primary text-primary-foreground text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center shrink-0">
                            {conv.no_leidos}
                          </span>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
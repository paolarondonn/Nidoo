import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import { base44 } from '@/api/base44Client';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import Home from './pages/Home';
import Favoritos from './pages/Favoritos';
import Publicar from './pages/Publicar';
import InmuebleDetalle from './pages/InmuebleDetalle';
import Perfil from './pages/Perfil';
import Mensajes from './pages/Mensajes';
import PageTransition from './components/layout/PageTransition';
import { AnimatePresence } from 'framer-motion';
import { useLocation } from 'react-router-dom';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();
  const location = useLocation();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="text-center">
          <span className="font-serif text-3xl text-primary">nido.</span>
        </div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login, but always return to home after login
      base44.auth.redirectToLogin(window.location.origin + '/');
      return null;
    }
  }

  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<PageTransition><Home /></PageTransition>} />
        <Route path="/favoritos" element={<PageTransition><Favoritos /></PageTransition>} />
        <Route path="/publicar" element={<PageTransition><Publicar /></PageTransition>} />
        <Route path="/inmueble/:id" element={<PageTransition><InmuebleDetalle /></PageTransition>} />
        <Route path="/perfil" element={<PageTransition><Perfil /></PageTransition>} />
        <Route path="/mensajes" element={<PageTransition><Mensajes /></PageTransition>} />
        <Route path="*" element={<PageTransition><PageNotFound /></PageTransition>} />
      </Routes>
    </AnimatePresence>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App
import { Link, useLocation } from 'react-router-dom';
import { Heart, Home, PlusCircle, MessageCircle, UserCircle } from 'lucide-react';

const scrollToTop = () => window.scrollTo({ top: 0, behavior: 'smooth' });

const links = [
  { to: '/', label: 'Buscar', icon: Home },
  { to: '/favoritos', label: 'Favoritos', icon: Heart },
  { to: '/publicar', label: 'Publicar', icon: PlusCircle },
  { to: '/mensajes', label: 'Mensajes', icon: MessageCircle },
  { to: '/perfil', label: 'Perfil', icon: UserCircle },
];

export default function Navbar() {
  const location = useLocation();
  const isActive = (to) => location.pathname === to;

  return (
    <>
      {/* Top header — desktop only */}
      <header
        className="hidden md:block fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border"
        style={{ paddingTop: 'env(safe-area-inset-top)' }}
      >
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <span className="font-serif text-2xl text-primary font-normal tracking-tight">nido.</span>
          </Link>
          <nav className="flex items-center gap-1">
            {links.map(({ to, label, icon: Icon }) => (
              <Link
                key={to}
                to={to}
                onClick={isActive(to) ? scrollToTop : undefined}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium transition-all min-h-[44px] ${
                  isActive(to)
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                }`}
              >
                <Icon size={15} />
                {label}
              </Link>
            ))}
          </nav>
        </div>
      </header>

      {/* Mobile top bar — logo only */}
      <header
        className="md:hidden fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border"
        style={{ paddingTop: 'env(safe-area-inset-top)' }}
      >
        <div className="px-4 h-14 flex items-center">
          <Link to="/" className="flex items-center">
            <span className="font-serif text-2xl text-primary font-normal tracking-tight">nido.</span>
          </Link>
        </div>
      </header>

      {/* Mobile bottom tab bar */}
      <nav
        className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-t border-border"
        style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
      >
        <div className="flex">
          {links.map(({ to, label, icon: Icon }) => (
            <Link
              key={to}
              to={to}
              onClick={isActive(to) ? scrollToTop : undefined}
              className={`flex-1 flex flex-col items-center justify-center gap-1 min-h-[56px] py-2 transition-colors select-none ${
                isActive(to) ? 'text-primary' : 'text-muted-foreground'
              }`}
            >
              <Icon size={22} strokeWidth={isActive(to) ? 2.5 : 1.8} />
              <span className="text-[10px] font-medium tracking-wide">{label}</span>
            </Link>
          ))}
        </div>
      </nav>
    </>
  );
}
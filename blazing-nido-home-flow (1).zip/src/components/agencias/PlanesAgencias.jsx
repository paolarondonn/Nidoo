import { useState } from 'react';
import { Check, Zap, Star, Building2, Trophy } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import ContactoPlanModal from './ContactoplanModal';

const PLANES = [
  {
    id: 'flex',
    nombre: 'Flex',
    precio: 29,
    priceId: 'price_1TP1IdLPiIj5Ii7DHsU7Ovjl',
    icon: Zap,
    color: 'border-border',
    descripcion: 'Para agencias pequeñas que empiezan.',
    destacado: false,
    features: [
      { texto: 'Hasta 10 inmuebles activos', ok: true },
      { texto: 'Perfil de agencia', ok: true },
      { texto: 'Estadísticas básicas', ok: true, badge: 'básico' },
      { texto: 'Visitas y contactos recibidos', ok: true },
      { texto: 'Anuncios destacados', ok: false },
      { texto: 'Estadísticas avanzadas', ok: false },
      { texto: 'Soporte prioritario', ok: false },
    ],
  },
  {
    id: 'basico',
    nombre: 'Básico',
    precio: 79,
    priceId: 'price_1TP1IdLPiIj5Ii7DcDspBrr8',
    icon: Building2,
    color: 'border-primary/40',
    descripcion: 'Para agencias en crecimiento.',
    destacado: false,
    features: [
      { texto: 'Hasta 50 inmuebles activos', ok: true },
      { texto: 'Perfil de agencia verificado ✓', ok: true },
      { texto: 'Estadísticas básicas', ok: true, badge: 'básico' },
      { texto: 'Visitas, contactos y favoritos', ok: true },
      { texto: 'Histórico de rendimiento (3 meses)', ok: true },
      { texto: 'Anuncios destacados', ok: false },
      { texto: 'Estadísticas avanzadas', ok: false },
      { texto: 'Soporte prioritario', ok: false },
    ],
  },
  {
    id: 'pro',
    nombre: 'Pro',
    precio: 149,
    priceId: 'price_1TP1IdLPiIj5Ii7DJRoh4i0j',
    icon: Trophy,
    color: 'border-primary',
    descripcion: 'Para agencias que quieren destacar.',
    destacado: true,
    features: [
      { texto: 'Inmuebles ilimitados', ok: true },
      { texto: 'Perfil de agencia verificado ✓', ok: true },
      { texto: 'Estadísticas básicas', ok: true, badge: 'básico' },
      { texto: 'Estadísticas avanzadas', ok: true, badge: 'avanzado' },
      { texto: 'Comparativa de mercado', ok: true },
      { texto: 'Histórico completo', ok: true },
      { texto: 'Anuncios destacados incluidos', ok: true },
      { texto: 'Soporte prioritario', ok: true },
    ],
  },
];

const badgeColors = {
  básico: 'bg-accent text-accent-foreground',
  avanzado: 'bg-primary/10 text-primary',
};

export default function PlanesAgencias() {
  const [planSeleccionado, setPlanSeleccionado] = useState(null);

  return (
    <section id="planes" className="py-20 px-4 bg-background">
      <div className="max-w-6xl mx-auto">
        {/* Cabecera */}
        <div className="text-center mb-4">
          <span className="text-xs font-semibold uppercase tracking-widest text-primary bg-primary/10 px-3 py-1 rounded-full">Para agencias</span>
        </div>
        <h2 className="font-serif text-4xl md:text-5xl text-center text-foreground mb-3">
          Publica con nido.
        </h2>
        <p className="text-center text-muted-foreground text-lg mb-3 max-w-xl mx-auto">
          Llega a miles de compradores y arrendatarios. Sin comisiones ocultas.
        </p>

        {/* Banner 1 año gratis */}
        <div className="flex justify-center mb-12">
          <div className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-5 py-2.5 rounded-full text-sm font-semibold shadow-lg">
            <Star size={15} fill="currentColor" />
            Primer año completamente gratis en todos los planes
            <Star size={15} fill="currentColor" />
          </div>
        </div>

        {/* Tarjetas */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
          {PLANES.map((plan, i) => {
            const Icon = plan.icon;
            return (
              <motion.div
                key={plan.id}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className={`relative bg-card rounded-3xl border-2 ${plan.color} p-7 flex flex-col gap-5 ${plan.destacado ? 'shadow-2xl scale-[1.03]' : 'shadow-sm'}`}
              >
                {plan.destacado && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2">
                    <span className="bg-primary text-primary-foreground text-xs font-bold px-4 py-1 rounded-full shadow">Más popular</span>
                  </div>
                )}

                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${plan.destacado ? 'bg-primary text-primary-foreground' : 'bg-accent text-accent-foreground'}`}>
                    <Icon size={20} />
                  </div>
                  <div>
                    <p className="font-semibold text-base">{plan.nombre}</p>
                    <p className="text-xs text-muted-foreground">{plan.descripcion}</p>
                  </div>
                </div>

                <div className="flex items-baseline gap-1">
                  <span className="font-serif text-5xl">{plan.precio}</span>
                  <span className="text-muted-foreground text-sm">€/mes</span>
                </div>
                <p className="text-xs text-primary font-medium -mt-3">🎉 1er año gratis · Sin tarjeta hasta que expire</p>

                <ul className="space-y-2.5 flex-1">
                  {plan.features.map((f, j) => (
                    <li key={j} className={`flex items-center gap-2.5 text-sm ${f.ok ? 'text-foreground' : 'text-muted-foreground/50'}`}>
                      <span className={`shrink-0 w-4 h-4 rounded-full flex items-center justify-center ${f.ok ? 'bg-primary/15 text-primary' : 'bg-muted'}`}>
                        {f.ok ? <Check size={11} strokeWidth={3} /> : <span className="w-1.5 h-0.5 bg-muted-foreground/30 rounded-full block" />}
                      </span>
                      <span>{f.texto}</span>
                      {f.badge && (
                        <span className={`ml-auto text-[10px] font-semibold px-2 py-0.5 rounded-full ${badgeColors[f.badge]}`}>
                          {f.badge}
                        </span>
                      )}
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => setPlanSeleccionado(plan)}
                  className={`w-full py-3 rounded-2xl font-semibold text-sm transition-all flex items-center justify-center gap-2 ${
                    plan.destacado
                      ? 'bg-primary text-primary-foreground hover:bg-primary/90'
                      : 'bg-accent text-accent-foreground hover:bg-primary hover:text-primary-foreground border border-border'
                  }`}
                >
                  Empezar gratis
                </button>
              </motion.div>
            );
          })}
        </div>

        <p className="text-center text-xs text-muted-foreground mt-8">
          Cancela cuando quieras · Sin permanencia · Pago seguro con Stripe
        </p>
      </div>

      <AnimatePresence>
        {planSeleccionado && (
          <ContactoPlanModal plan={planSeleccionado} onClose={() => setPlanSeleccionado(null)} />
        )}
      </AnimatePresence>
    </section>
  );
}
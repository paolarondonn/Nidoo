import { useState } from 'react';
import { X, Mail, Send, Loader2, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';

const CONTACT_EMAIL = 'contacto.nidoapp@gmail.com';

export default function ContactoPlanModal({ plan, onClose }) {
  const [tab, setTab] = useState('opciones'); // 'opciones' | 'formulario'
  const [form, setForm] = useState({ nombre: '', email: '', mensaje: '' });
  const [enviando, setEnviando] = useState(false);
  const [enviado, setEnviado] = useState(false);

  const handleEmailCliente = () => {
    const subject = encodeURIComponent(`Interés en Plan ${plan.nombre} - nido.`);
    const body = encodeURIComponent(`Hola,\n\nMe interesa contratar el Plan ${plan.nombre} (${plan.precio}€/mes).\n\nPor favor, contadme cómo proceder.\n\nGracias.`);
    window.open(`mailto:${CONTACT_EMAIL}?subject=${subject}&body=${body}`);
  };

  const handleEnviar = async (e) => {
    e.preventDefault();
    setEnviando(true);
    await base44.integrations.Core.SendEmail({
      to: CONTACT_EMAIL,
      subject: `Interés en Plan ${plan.nombre} - nido.`,
      body: `Nombre: ${form.nombre}\nEmail: ${form.email}\nPlan: ${plan.nombre} (${plan.precio}€/mes)\n\nMensaje:\n${form.mensaje}`,
    });
    setEnviando(false);
    setEnviado(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/40 backdrop-blur-sm" onClick={onClose}>
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 40 }}
        transition={{ duration: 0.25 }}
        onClick={e => e.stopPropagation()}
        className="w-full max-w-md bg-card rounded-3xl border border-border shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 pt-6 pb-4">
          <div>
            <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Plan {plan.nombre}</p>
            <h2 className="font-serif text-2xl">Contactar con nosotros</h2>
          </div>
          <button onClick={onClose} className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-accent transition-colors">
            <X size={18} />
          </button>
        </div>

        <div className="px-6 pb-6">
          <AnimatePresence mode="wait">
            {/* Pantalla de opciones */}
            {tab === 'opciones' && !enviado && (
              <motion.div key="opciones" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-3">
                <p className="text-sm text-muted-foreground mb-4">¿Cómo prefieres ponerte en contacto?</p>

                <button
                  onClick={handleEmailCliente}
                  className="w-full flex items-center gap-4 p-4 rounded-2xl border border-border hover:border-primary/40 hover:bg-accent transition-all text-left"
                >
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                    <Mail size={18} className="text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold text-sm">Abrir mi cliente de email</p>
                    <p className="text-xs text-muted-foreground">Se abrirá con el mensaje ya redactado</p>
                  </div>
                </button>

                <button
                  onClick={() => setTab('formulario')}
                  className="w-full flex items-center gap-4 p-4 rounded-2xl border border-border hover:border-primary/40 hover:bg-accent transition-all text-left"
                >
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                    <Send size={18} className="text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold text-sm">Rellenar formulario</p>
                    <p className="text-xs text-muted-foreground">Te responderemos a tu correo</p>
                  </div>
                </button>
              </motion.div>
            )}

            {/* Formulario */}
            {tab === 'formulario' && !enviado && (
              <motion.form key="formulario" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }} onSubmit={handleEnviar} className="space-y-3">
                <button type="button" onClick={() => setTab('opciones')} className="text-xs text-muted-foreground hover:text-foreground transition-colors mb-1">← Volver</button>

                <div>
                  <label className="text-xs font-medium text-muted-foreground block mb-1">Nombre</label>
                  <input
                    required
                    value={form.nombre}
                    onChange={e => setForm(f => ({ ...f, nombre: e.target.value }))}
                    placeholder="Tu nombre"
                    className="w-full px-3 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-1 focus:ring-ring"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground block mb-1">Email</label>
                  <input
                    required
                    type="email"
                    value={form.email}
                    onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                    placeholder="tu@email.com"
                    className="w-full px-3 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-1 focus:ring-ring"
                  />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground block mb-1">Mensaje <span className="text-muted-foreground/50">(opcional)</span></label>
                  <textarea
                    value={form.mensaje}
                    onChange={e => setForm(f => ({ ...f, mensaje: e.target.value }))}
                    placeholder="Cuéntanos algo sobre tu agencia..."
                    rows={3}
                    className="w-full px-3 py-2.5 rounded-xl border border-input bg-background text-sm focus:outline-none focus:ring-1 focus:ring-ring resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={enviando}
                  className="w-full bg-primary text-primary-foreground py-3 rounded-2xl font-semibold text-sm flex items-center justify-center gap-2 hover:bg-primary/90 transition-colors disabled:opacity-60"
                >
                  {enviando ? <Loader2 size={15} className="animate-spin" /> : <Send size={15} />}
                  {enviando ? 'Enviando...' : 'Enviar mensaje'}
                </button>
              </motion.form>
            )}

            {/* Éxito */}
            {enviado && (
              <motion.div key="exito" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="text-center py-8 space-y-3">
                <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                  <CheckCircle2 size={28} className="text-primary" />
                </div>
                <h3 className="font-serif text-2xl">¡Mensaje enviado!</h3>
                <p className="text-sm text-muted-foreground">Te responderemos lo antes posible en <strong>{form.email}</strong>.</p>
                <button onClick={onClose} className="mt-4 text-sm font-medium text-primary hover:underline">Cerrar</button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
}
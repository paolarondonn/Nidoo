import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MessageCircle, X } from 'lucide-react';
import ChatConversacion from './ChatConversacion';
import { motion, AnimatePresence } from 'framer-motion';

export default function ChatButton({ inmuebleId, inmuebleTitulo, anuncianteEmail, user }) {
  const [abierto, setAbierto] = useState(false);
  const navigate = useNavigate();

  if (!user) {
    return (
      <button
        onClick={() => navigate('/perfil')}
        className="w-full flex items-center justify-center gap-2 border border-border py-3 rounded-xl text-sm font-medium hover:bg-accent transition-colors"
      >
        <MessageCircle size={15} /> Iniciar chat
      </button>
    );
  }

  // No chatear contigo mismo
  if (user.email === anuncianteEmail) return null;

  return (
    <div>
      <button
        onClick={() => setAbierto(!abierto)}
        className="w-full flex items-center justify-center gap-2 border border-border py-3 rounded-xl text-sm font-medium hover:bg-accent transition-colors"
      >
        <MessageCircle size={15} />
        {abierto ? 'Cerrar chat' : 'Enviar mensaje'}
      </button>

      <AnimatePresence>
        {abierto && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-3 overflow-hidden"
          >
            <ChatConversacion
              inmuebleId={inmuebleId}
              inmuebleTitulo={inmuebleTitulo}
              otroEmail={anuncianteEmail}
              user={user}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
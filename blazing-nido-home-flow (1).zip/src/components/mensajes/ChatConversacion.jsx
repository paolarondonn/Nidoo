import { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Send, Loader2 } from 'lucide-react';

export default function ChatConversacion({ inmuebleId, inmuebleTitulo, otroEmail, user }) {
  const [texto, setTexto] = useState('');
  const bottomRef = useRef(null);
  const queryClient = useQueryClient();

  const { data: mensajes = [] } = useQuery({
    queryKey: ['chat', inmuebleId, otroEmail],
    queryFn: async () => {
      const enviados = await base44.entities.Mensaje.filter({ remitente_email: user.email, inmueble_id: inmuebleId });
      const recibidos = await base44.entities.Mensaje.filter({ destinatario_email: user.email, inmueble_id: inmuebleId });
      return [...enviados, ...recibidos].sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
    },
    enabled: !!user,
    refetchInterval: 4000,
  });

  // Marcar como leídos
  useEffect(() => {
    const noLeidos = mensajes.filter(m => m.destinatario_email === user.email && !m.leido);
    noLeidos.forEach(m => base44.entities.Mensaje.update(m.id, { leido: true }));
  }, [mensajes, user]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [mensajes]);

  const sendMutation = useMutation({
    mutationFn: async () => {
      await base44.entities.Mensaje.create({
        inmueble_id: inmuebleId,
        inmueble_titulo: inmuebleTitulo,
        remitente_email: user.email,
        remitente_nombre: user.full_name || user.email,
        destinatario_email: otroEmail,
        contenido: texto.trim(),
        leido: false,
      });
    },
    onSuccess: () => {
      setTexto('');
      queryClient.invalidateQueries({ queryKey: ['chat', inmuebleId, otroEmail] });
      queryClient.invalidateQueries({ queryKey: ['mensajes'] });
    },
  });

  const handleSend = (e) => {
    e.preventDefault();
    if (!texto.trim() || sendMutation.isPending) return;
    sendMutation.mutate();
  };

  const formatHora = (date) => {
    if (!date) return '';
    return new Date(date).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="flex flex-col bg-card border border-border rounded-2xl overflow-hidden" style={{ height: 'calc(100vh - 220px)' }}>
      {/* Header */}
      <div className="px-4 py-3 border-b border-border">
        <p className="font-semibold text-sm truncate">{inmuebleTitulo || 'Conversación'}</p>
        <p className="text-xs text-muted-foreground truncate">{otroEmail}</p>
      </div>

      {/* Mensajes */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {mensajes.length === 0 && (
          <p className="text-center text-sm text-muted-foreground py-8">Aún no hay mensajes. ¡Sé el primero en escribir!</p>
        )}
        {mensajes.map(m => {
          const esMio = m.remitente_email === user.email;
          return (
            <div key={m.id} className={`flex ${esMio ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[75%] rounded-2xl px-4 py-2.5 ${esMio ? 'bg-primary text-primary-foreground rounded-br-sm' : 'bg-secondary text-foreground rounded-bl-sm'}`}>
                <p className="text-sm leading-relaxed">{m.contenido}</p>
                <p className={`text-[10px] mt-1 ${esMio ? 'text-primary-foreground/60' : 'text-muted-foreground'}`}>{formatHora(m.created_date)}</p>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <form onSubmit={handleSend} className="border-t border-border p-3 flex gap-2 items-end">
        <textarea
          value={texto}
          onChange={e => setTexto(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(e); } }}
          placeholder="Escribe un mensaje..."
          rows={1}
          className="flex-1 resize-none bg-background border border-border rounded-xl px-4 py-2.5 text-sm outline-none focus:border-primary transition-colors placeholder:text-muted-foreground max-h-28"
          style={{ fontSize: '16px' }}
        />
        <button
          type="submit"
          disabled={!texto.trim() || sendMutation.isPending}
          className="bg-primary text-primary-foreground p-2.5 rounded-xl hover:bg-primary/90 transition-colors disabled:opacity-50 shrink-0"
        >
          {sendMutation.isPending ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
        </button>
      </form>
    </div>
  );
}
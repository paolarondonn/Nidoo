import { useState } from 'react';
import { useAuth } from '@/lib/AuthContext';
import { Trash2, AlertTriangle, X } from 'lucide-react';

export default function DeleteAccountButton() {
  const { deleteAccount } = useAuth();
  const [step, setStep] = useState('idle'); // idle | confirm | deleting

  const handleConfirm = async () => {
    setStep('deleting');
    await deleteAccount();
  };

  if (step === 'confirm') {
    return (
      <div className="border border-destructive/40 bg-destructive/5 rounded-xl p-4 space-y-3">
        <div className="flex items-start gap-2">
          <AlertTriangle size={16} className="text-destructive mt-0.5 shrink-0" />
          <div>
            <p className="text-sm font-semibold text-destructive">¿Eliminar cuenta?</p>
            <p className="text-xs text-muted-foreground mt-0.5">
              Se eliminarán todos tus datos, favoritos e inmuebles publicados. Esta acción no se puede deshacer.
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={handleConfirm}
            disabled={step === 'deleting'}
            className="flex-1 bg-destructive text-white py-2 rounded-lg text-sm font-semibold hover:bg-destructive/90 transition-colors disabled:opacity-60"
          >
            {step === 'deleting' ? 'Eliminando...' : 'Sí, eliminar mi cuenta'}
          </button>
          <button
            onClick={() => setStep('idle')}
            className="p-2 rounded-lg border border-border hover:bg-accent transition-colors"
          >
            <X size={16} />
          </button>
        </div>
      </div>
    );
  }

  return (
    <button
      onClick={() => setStep('confirm')}
      className="flex items-center gap-2 text-sm text-destructive/70 hover:text-destructive transition-colors py-2"
    >
      <Trash2 size={15} />
      Eliminar cuenta y datos
    </button>
  );
}
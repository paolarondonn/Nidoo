import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { CheckCircle2, Loader2 } from 'lucide-react';

export default function ContactoForm({ inmuebleId, inmuebleTitulo, onSuccess }) {
  const [form, setForm] = useState({ nombre: '', email: '', telefono: '', mensaje: '', fecha_preferida: '' });
  const [enviado, setEnviado] = useState(false);
  const [cargando, setCargando] = useState(false);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setCargando(true);
    await base44.entities.ContactoVisita.create({
      ...form,
      inmueble_id: inmuebleId,
      inmueble_titulo: inmuebleTitulo,
    });
    setCargando(false);
    setEnviado(true);
    setTimeout(onSuccess, 2000);
  };

  if (enviado) {
    return (
      <div className="text-center py-4">
        <CheckCircle2 size={28} className="text-primary mx-auto mb-2" />
        <p className="text-sm font-medium">¡Solicitud enviada!</p>
        <p className="text-xs text-muted-foreground">El anunciante se pondrá en contacto contigo pronto.</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="pt-3 space-y-3 border-t border-border">
      <div>
        <Label className="text-xs">Nombre *</Label>
        <Input value={form.nombre} onChange={(e) => set('nombre', e.target.value)} required placeholder="Tu nombre" className="mt-1 h-9 text-sm" />
      </div>
      <div>
        <Label className="text-xs">Email *</Label>
        <Input type="email" value={form.email} onChange={(e) => set('email', e.target.value)} required placeholder="tu@email.com" className="mt-1 h-9 text-sm" />
      </div>
      <div>
        <Label className="text-xs">Teléfono</Label>
        <Input value={form.telefono} onChange={(e) => set('telefono', e.target.value)} placeholder="+34 600 000 000" className="mt-1 h-9 text-sm" />
      </div>
      <div>
        <Label className="text-xs">Fecha preferida</Label>
        <Input type="date" value={form.fecha_preferida} onChange={(e) => set('fecha_preferida', e.target.value)} className="mt-1 h-9 text-sm" />
      </div>
      <div>
        <Label className="text-xs">Mensaje</Label>
        <Textarea value={form.mensaje} onChange={(e) => set('mensaje', e.target.value)} placeholder="¿Tienes alguna pregunta?" className="mt-1 text-sm min-h-16" />
      </div>
      <button type="submit" disabled={cargando}
        className="w-full bg-primary text-primary-foreground py-2.5 rounded-xl text-sm font-semibold hover:bg-primary/90 transition-colors disabled:opacity-60 flex items-center justify-center gap-2">
        {cargando ? <><Loader2 size={14} className="animate-spin" /> Enviando...</> : 'Enviar solicitud'}
      </button>
    </form>
  );
}
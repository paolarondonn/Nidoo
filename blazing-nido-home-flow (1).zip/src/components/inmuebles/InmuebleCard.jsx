import { Link } from 'react-router-dom';
import { Heart, MapPin, Maximize2, BedDouble, TrendingDown, Clock } from 'lucide-react';
import { motion } from 'framer-motion';

const energyColors = {
  A: 'bg-green-100 text-green-800',
  B: 'bg-lime-100 text-lime-800',
  C: 'bg-yellow-100 text-yellow-800',
  D: 'bg-orange-100 text-orange-800',
  E: 'bg-orange-100 text-orange-800',
  F: 'bg-red-100 text-red-800',
  G: 'bg-red-200 text-red-900',
};

export default function InmuebleCard({ inmueble, isFavorito, onToggleFavorito }) {
  const foto = inmueble.fotos?.[0] || `https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=600&q=80`;
  const precioBajado = inmueble.precio_original && inmueble.precio < inmueble.precio_original;

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className="group bg-card rounded-2xl overflow-hidden border border-border hover:shadow-xl hover:-translate-y-1 transition-all duration-300"
    >
      {/* Imagen */}
      <Link to={`/inmueble/${inmueble.id}`} className="block relative overflow-hidden aspect-[4/3]">
        <img
          src={foto}
          alt={inmueble.titulo}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        {inmueble.destacado && (
          <span className="absolute top-3 left-3 bg-primary text-primary-foreground text-xs font-semibold px-2.5 py-1 rounded-full">
            Destacado
          </span>
        )}
        {precioBajado && (
          <span className="absolute top-3 left-3 bg-destructive text-white text-xs font-semibold px-2.5 py-1 rounded-full flex items-center gap-1">
            <TrendingDown size={11} /> Precio bajado
          </span>
        )}
        <button
          onClick={(e) => { e.preventDefault(); onToggleFavorito(inmueble.id); }}
          className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-sm transition-all ${
            isFavorito ? 'bg-red-500 text-white' : 'bg-white/80 text-gray-600 hover:bg-white'
          }`}
        >
          <Heart size={15} fill={isFavorito ? 'currentColor' : 'none'} />
        </button>
      </Link>

      {/* Contenido */}
      <Link to={`/inmueble/${inmueble.id}`} className="block p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium">
            {inmueble.tipo_inmueble} en {inmueble.tipo_operacion}
          </p>
          {inmueble.certificado_energetico && (
            <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${energyColors[inmueble.certificado_energetico] || 'bg-gray-100 text-gray-800'}`}>
              {inmueble.certificado_energetico}
            </span>
          )}
        </div>

        <h3 className="font-serif text-lg leading-snug text-foreground mb-1 line-clamp-2">
          {inmueble.titulo}
        </h3>

        <div className="flex items-center gap-1 text-muted-foreground text-xs mb-3">
          <MapPin size={12} />
          <span>{inmueble.barrio ? `${inmueble.barrio}, ` : ''}{inmueble.ciudad}</span>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <span className="font-serif text-2xl font-normal text-foreground">
              {inmueble.precio?.toLocaleString('es-ES')}€
            </span>
            {inmueble.tipo_operacion === 'alquiler' && (
              <span className="text-muted-foreground text-sm">/mes</span>
            )}
            {precioBajado && (
              <span className="ml-2 text-xs text-muted-foreground line-through">
                {inmueble.precio_original?.toLocaleString('es-ES')}€
              </span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-3 mt-3 pt-3 border-t border-border text-xs text-muted-foreground">
          {inmueble.habitaciones && (
            <span className="flex items-center gap-1"><BedDouble size={13} />{inmueble.habitaciones} hab.</span>
          )}
          {inmueble.superficie && (
            <span className="flex items-center gap-1"><Maximize2 size={13} />{inmueble.superficie} m²</span>
          )}
          {inmueble.dias_publicado > 0 && (
            <span className="flex items-center gap-1 ml-auto"><Clock size={13} />{inmueble.dias_publicado}d</span>
          )}
        </div>

        {/* Extras pills */}
        {inmueble.extras && (
          <div className="flex flex-wrap gap-1.5 mt-3">
            {inmueble.extras.terraza && <span className="text-xs bg-accent text-accent-foreground px-2 py-0.5 rounded-full">Terraza</span>}
            {inmueble.extras.garaje && <span className="text-xs bg-accent text-accent-foreground px-2 py-0.5 rounded-full">Garaje</span>}
            {inmueble.extras.piscina && <span className="text-xs bg-accent text-accent-foreground px-2 py-0.5 rounded-full">Piscina</span>}
            {inmueble.extras.mascotas && <span className="text-xs bg-accent text-accent-foreground px-2 py-0.5 rounded-full">Mascotas</span>}
            {inmueble.extras.ascensor && <span className="text-xs bg-accent text-accent-foreground px-2 py-0.5 rounded-full">Ascensor</span>}
          </div>
        )}
      </Link>
    </motion.div>
  );
}
import { useState } from 'react';
import { Sliders, ChevronDown, ChevronUp, X, Car, Trees, Waves, PawPrint, Accessibility, Wind, Thermometer, Building2, Navigation, School, ShoppingCart, Stethoscope, Bike } from 'lucide-react';
import { Slider } from '@/components/ui/slider';
import { motion, AnimatePresence } from 'framer-motion';

const EXTRAS = [
  { key: 'garaje', label: 'Garaje', icon: Car },
  { key: 'terraza', label: 'Terraza', icon: Trees },
  { key: 'piscina', label: 'Piscina', icon: Waves },
  { key: 'mascotas', label: 'Mascotas', icon: PawPrint },
  { key: 'accesibilidad', label: 'Accesible', icon: Accessibility },
  { key: 'aire_acondicionado', label: 'Aire A/C', icon: Wind },
  { key: 'calefaccion', label: 'Calefacción', icon: Thermometer },
  { key: 'ascensor', label: 'Ascensor', icon: Building2 },
];

const SERVICIOS = [
  { key: 'metro', label: 'Metro', icon: Navigation },
  { key: 'colegio', label: 'Colegio', icon: School },
  { key: 'supermercado', label: 'Super', icon: ShoppingCart },
  { key: 'hospital', label: 'Hospital', icon: Stethoscope },
  { key: 'parque', label: 'Parque', icon: Trees },
  { key: 'carril_bici', label: 'Carril bici', icon: Bike },
];

const CERTIFICADOS = ['A', 'B', 'C', 'D', 'E', 'F', 'G'];

export default function FiltrosPanel({ filtros, onChange, onClear }) {
  const [expandido, setExpandido] = useState(false);

  const set = (key, value) => onChange({ ...filtros, [key]: value });

  const toggleExtra = (key) => {
    const extras = filtros.extras || {};
    set('extras', { ...extras, [key]: !extras[key] });
  };

  const toggleServicio = (key) => {
    const servicios = filtros.servicios || {};
    set('servicios', { ...servicios, [key]: !servicios[key] });
  };

  const activeCount = [
    filtros.habitaciones,
    filtros.precioMin,
    filtros.precioMax,
    filtros.superficieMin,
    filtros.tipo_inmueble,
    filtros.certificado_energetico,
    filtros.orientacion,
    filtros.tipo_contrato,
    ...(Object.values(filtros.extras || {}).filter(Boolean)),
    ...(Object.values(filtros.servicios || {}).filter(Boolean)),
  ].filter(Boolean).length;

  const precioMax = filtros.tipo_operacion === 'compra' ? 2000000 : 5000;
  const precioStep = filtros.tipo_operacion === 'compra' ? 10000 : 50;

  return (
    <div className="bg-card border border-border rounded-2xl overflow-hidden">
      {/* Filtros básicos siempre visibles */}
      <div className="p-4 flex flex-wrap gap-3 items-center">
        {/* Habitaciones */}
        <div className="flex items-center gap-1">
          {[0, 1, 2, 3, 4, 5].map((n) => (
            <button
              key={n}
              onClick={() => set('habitaciones', filtros.habitaciones === n ? null : n)}
              className={`w-9 h-9 rounded-full text-sm font-medium transition-all border ${
                filtros.habitaciones === n
                  ? 'bg-primary text-primary-foreground border-primary'
                  : 'border-border bg-background hover:border-primary/50 text-muted-foreground'
              }`}
            >
              {n === 0 ? 'T' : n === 5 ? '5+' : n}
            </button>
          ))}
        </div>

        {/* Precio range */}
        <div className="flex-1 min-w-48">
          <p className="text-xs text-muted-foreground mb-1">
            Precio: {filtros.precioMin ? `${filtros.precioMin.toLocaleString()}€` : '0€'} — {filtros.precioMax ? `${filtros.precioMax.toLocaleString()}€` : 'sin límite'}
          </p>
          <Slider
            min={0}
            max={precioMax}
            step={precioStep}
            value={[filtros.precioMin || 0, filtros.precioMax || precioMax]}
            onValueChange={([min, max]) => onChange({ ...filtros, precioMin: min || null, precioMax: max >= precioMax ? null : max })}
            className="w-full"
          />
        </div>

        {/* Toggle avanzados */}
        <button
          onClick={() => setExpandido(!expandido)}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium border transition-all ${
            expandido || activeCount > 0
              ? 'bg-primary text-primary-foreground border-primary'
              : 'border-border hover:border-primary/50 text-muted-foreground'
          }`}
        >
          <Sliders size={14} />
          Filtros {activeCount > 0 && `(${activeCount})`}
          {expandido ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
        </button>

        {activeCount > 0 && (
          <button onClick={onClear} className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 transition-colors">
            <X size={13} /> Limpiar
          </button>
        )}
      </div>

      {/* Filtros avanzados */}
      <AnimatePresence>
        {expandido && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden border-t border-border"
          >
            <div className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Tipo inmueble */}
              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Tipo inmueble</p>
                <div className="flex flex-wrap gap-2">
                  {['piso', 'casa', 'estudio', 'ático', 'dúplex'].map((t) => (
                    <button key={t} onClick={() => set('tipo_inmueble', filtros.tipo_inmueble === t ? null : t)}
                      className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all capitalize ${filtros.tipo_inmueble === t ? 'bg-primary text-primary-foreground border-primary' : 'border-border hover:border-primary/40 text-muted-foreground'}`}>
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              {/* Superficie */}
              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                  Superficie mín: {filtros.superficieMin || 0} m²
                </p>
                <Slider
                  min={0} max={300} step={10}
                  value={[filtros.superficieMin || 0]}
                  onValueChange={([v]) => set('superficieMin', v || null)}
                  className="w-full"
                />
              </div>

              {/* Certificado energético */}
              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Certificado energético</p>
                <div className="flex gap-1.5">
                  {CERTIFICADOS.map((c) => (
                    <button key={c} onClick={() => set('certificado_energetico', filtros.certificado_energetico === c ? null : c)}
                      className={`w-8 h-8 rounded-lg text-xs font-bold transition-all ${filtros.certificado_energetico === c ? 'bg-primary text-primary-foreground' : 'bg-accent text-accent-foreground hover:bg-primary/20'}`}>
                      {c}
                    </button>
                  ))}
                </div>
              </div>

              {/* Orientación */}
              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Orientación</p>
                <div className="flex flex-wrap gap-2">
                  {['norte', 'sur', 'este', 'oeste'].map((o) => (
                    <button key={o} onClick={() => set('orientacion', filtros.orientacion === o ? null : o)}
                      className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all capitalize ${filtros.orientacion === o ? 'bg-primary text-primary-foreground border-primary' : 'border-border hover:border-primary/40 text-muted-foreground'}`}>
                      {o}
                    </button>
                  ))}
                </div>
              </div>

              {/* Tipo contrato */}
              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Tipo de contrato</p>
                <div className="flex flex-wrap gap-2">
                  {['larga duración', 'temporal', 'estudiantes'].map((c) => (
                    <button key={c} onClick={() => set('tipo_contrato', filtros.tipo_contrato === c ? null : c)}
                      className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all capitalize ${filtros.tipo_contrato === c ? 'bg-primary text-primary-foreground border-primary' : 'border-border hover:border-primary/40 text-muted-foreground'}`}>
                      {c}
                    </button>
                  ))}
                </div>
              </div>

              {/* Extras */}
              <div className="md:col-span-2 lg:col-span-3">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Extras</p>
                <div className="flex flex-wrap gap-2">
                  {EXTRAS.map(({ key, label, icon: Icon }) => {
                    const active = !!(filtros.extras || {})[key];
                    return (
                      <button key={key} onClick={() => toggleExtra(key)}
                        className={`flex flex-col items-center gap-1.5 px-3 py-2.5 rounded-2xl border transition-all w-[72px] ${active ? 'bg-primary text-primary-foreground border-primary' : 'border-border bg-background hover:border-primary/40 text-muted-foreground hover:text-foreground'}`}>
                        <Icon size={20} strokeWidth={1.7} />
                        <span className="text-[10px] font-medium leading-tight text-center">{label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Servicios */}
              <div className="md:col-span-2 lg:col-span-3">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Servicios cercanos</p>
                <div className="flex flex-wrap gap-2">
                  {SERVICIOS.map(({ key, label, icon: Icon }) => {
                    const active = !!(filtros.servicios || {})[key];
                    return (
                      <button key={key} onClick={() => toggleServicio(key)}
                        className={`flex flex-col items-center gap-1.5 px-3 py-2.5 rounded-2xl border transition-all w-[72px] ${active ? 'bg-primary text-primary-foreground border-primary' : 'border-border bg-background hover:border-primary/40 text-muted-foreground hover:text-foreground'}`}>
                        <Icon size={20} strokeWidth={1.7} />
                        <span className="text-[10px] font-medium leading-tight text-center">{label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
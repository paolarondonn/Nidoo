import { useState } from 'react';
import { Sparkles, Loader2, ArrowRight } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';

const EJEMPLOS = [
  'Trabajo en Chamberí, tengo un perro, voy en bici, presupuesto 1.200€',
  'Busco piso céntrico en Barcelona, 2 habitaciones, con terraza y luz',
  'Estudiante, Madrid, habitación o estudio hasta 700€, cerca del metro',
];

export default function BusquedaIA({ onFiltrosGenerados }) {
  const [texto, setTexto] = useState('');
  const [cargando, setCargando] = useState(false);
  const [resultado, setResultado] = useState(null);

  const buscar = async () => {
    if (!texto.trim()) return;
    setCargando(true);
    setResultado(null);
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `Eres un asistente de búsqueda de pisos en España. 
El usuario describe su situación: "${texto}"

Extrae los filtros de búsqueda relevantes y devuelve un objeto JSON con los campos disponibles.
También devuelve una explicación breve y amigable de por qué esos filtros encajan.

Campos disponibles:
- tipo_operacion: "alquiler" | "compra"
- habitaciones: número (1-5)
- precioMax: número en euros
- precioMin: número en euros  
- ciudad: string
- extras.mascotas: boolean
- extras.terraza: boolean
- extras.garaje: boolean
- extras.ascensor: boolean
- servicios.metro: boolean
- servicios.carril_bici: boolean
- tipo_contrato: "larga duración" | "temporal" | "estudiantes"
- superficieMin: número en m²

Responde con JSON: { filtros: {...}, explicacion: "..." }`,
      response_json_schema: {
        type: 'object',
        properties: {
          filtros: { type: 'object' },
          explicacion: { type: 'string' },
        },
      },
    });
    setCargando(false);
    if (res?.filtros) {
      setResultado(res.explicacion);
      onFiltrosGenerados(res.filtros);
    }
  };

  return (
    <div className="bg-primary/5 border border-primary/20 rounded-2xl p-5">
      <div className="flex items-center gap-2 mb-3">
        <Sparkles size={16} className="text-primary" />
        <span className="text-sm font-semibold text-primary">Búsqueda con IA</span>
        <span className="text-xs text-muted-foreground">— Describe tu situación en lenguaje natural</span>
      </div>

      <div className="flex gap-2">
        <input
          value={texto}
          onChange={(e) => setTexto(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && buscar()}
          placeholder="Ej: Trabajo en Salamanca, tengo gato, presupuesto 900€..."
          className="flex-1 bg-card border border-border rounded-xl px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/30 placeholder:text-muted-foreground"
        />
        <button
          onClick={buscar}
          disabled={cargando || !texto.trim()}
          className="bg-primary text-primary-foreground px-4 py-2.5 rounded-xl text-sm font-medium hover:bg-primary/90 transition-colors disabled:opacity-50 flex items-center gap-1.5"
        >
          {cargando ? <Loader2 size={14} className="animate-spin" /> : <ArrowRight size={14} />}
          {cargando ? 'Analizando...' : 'Buscar'}
        </button>
      </div>

      {/* Ejemplos */}
      <div className="flex flex-wrap gap-2 mt-3">
        {EJEMPLOS.map((e) => (
          <button key={e} onClick={() => setTexto(e)}
            className="text-xs text-primary/70 hover:text-primary border border-primary/20 hover:border-primary/40 px-2.5 py-1 rounded-full transition-all">
            {e.substring(0, 40)}...
          </button>
        ))}
      </div>

      <AnimatePresence>
        {resultado && (
          <motion.div
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-3 p-3 bg-primary/10 rounded-xl text-sm text-primary"
          >
            <Sparkles size={13} className="inline mr-1.5" />
            {resultado}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
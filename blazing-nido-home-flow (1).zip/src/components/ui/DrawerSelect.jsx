import { useState } from 'react';
import { Drawer } from 'vaul';
import { Check, ChevronDown } from 'lucide-react';

export default function DrawerSelect({ label, value, onChange, options, placeholder = 'Sin especificar' }) {
  const [open, setOpen] = useState(false);
  const selected = options.find((o) => o.value === value);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="mt-1 w-full flex items-center justify-between bg-background border border-input rounded-md px-3 py-2.5 text-sm text-left min-h-[44px] hover:border-primary/50 transition-colors"
      >
        <span className={selected ? 'text-foreground capitalize' : 'text-muted-foreground'}>
          {selected ? selected.label : placeholder}
        </span>
        <ChevronDown size={15} className="text-muted-foreground shrink-0" />
      </button>

      <Drawer.Root open={open} onOpenChange={setOpen}>
        <Drawer.Portal>
          <Drawer.Overlay className="fixed inset-0 bg-black/40 z-50" />
          <Drawer.Content
            className="fixed bottom-0 left-0 right-0 z-50 bg-card rounded-t-2xl outline-none"
            style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
          >
            <div className="w-10 h-1 bg-border rounded-full mx-auto mt-3 mb-4" />
            {label && (
              <p className="text-sm font-semibold text-muted-foreground uppercase tracking-wider px-5 mb-3">
                {label}
              </p>
            )}
            <div className="overflow-y-auto max-h-[60vh] pb-4">
              <button
                type="button"
                onClick={() => { onChange(''); setOpen(false); }}
                className="w-full flex items-center justify-between px-5 py-3.5 min-h-[48px] hover:bg-accent transition-colors text-sm text-muted-foreground"
              >
                {placeholder}
                {!value && <Check size={16} className="text-primary" />}
              </button>
              {options.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => { onChange(opt.value); setOpen(false); }}
                  className="w-full flex items-center justify-between px-5 py-3.5 min-h-[48px] hover:bg-accent transition-colors text-sm capitalize"
                >
                  {opt.label}
                  {value === opt.value && <Check size={16} className="text-primary" />}
                </button>
              ))}
            </div>
          </Drawer.Content>
        </Drawer.Portal>
      </Drawer.Root>
    </>
  );
}
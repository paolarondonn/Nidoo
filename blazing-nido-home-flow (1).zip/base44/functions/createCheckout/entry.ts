import Stripe from 'npm:stripe@14';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));

Deno.serve(async (req) => {
  try {
    const { priceId, planName } = await req.json();

    if (!priceId) {
      return Response.json({ error: 'priceId requerido' }, { status: 400 });
    }

    const origin = req.headers.get('origin') || 'https://app.base44.com';

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [{ price: priceId, quantity: 1 }],
      mode: 'subscription',
      subscription_data: {
        trial_period_days: 365, // 1 año gratis
      },
      success_url: `${origin}/?pago=exitoso&plan=${encodeURIComponent(planName)}`,
      cancel_url: `${origin}/?pago=cancelado`,
      metadata: {
        base44_app_id: Deno.env.get('BASE44_APP_ID'),
        plan: planName,
      },
    });

    return Response.json({ url: session.url });
  } catch (error) {
    console.error('Error creando checkout:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});